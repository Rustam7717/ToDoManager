package com.example.todomanager.utils;

public class Constants {
    public static final String USER_TASK = "user_task";
}
